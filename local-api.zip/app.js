const express = require('express')
const cors = require('cors')
const app = express()
const PORT = 8080;
const { cats } = require("./data.js");
app.use(cors());
app.get('/api/cats', function (req, res) {
  res.json(cats)
})

app.listen(PORT, () => console.log(`server running on ${PORT}`));